package com.company;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


class Cart {

    List<Product> cartItems = new ArrayList<>();
    List<Product> products;

    Cart(List<Product> products) {
        this.products = products;
    }

    public void addProductToCartByPID(int pid) throws SQLException {
        Product product = getProductByProductID(pid);
        addToCart(product);
    }

    private Product getProductByProductID(int pid){
        Product product = null;
        for (Product prod: products) {
            if (prod.getPid() == pid) {
                product = prod;
                break;
            }
        }
        return product;
    }

    private void addToCart(Product product) throws SQLException {
        Connection conn = new SQLDriver().getConnection();
        PreparedStatement ps = conn.prepareStatement("insert into cart values(?,?)");
        ps.setInt(1,1);
        ps.setInt(2, product.getPid());
        ps.executeUpdate();
        cartItems.add(product);
    }

    public void removeProductByPID(int pid) throws SQLException {
        Connection conn = new SQLDriver().getConnection();
        PreparedStatement ps = conn.prepareStatement("DELETE from cart WHERE pid = ?");
        ps.setInt(1, pid);
        ps.executeUpdate();
        Product prod = getProductByProductID(pid);
        cartItems.remove(prod);
    }

    void printCartItems() {
        for (Product prod: cartItems) {
            System.out.println(prod.getName());
        }
    }

}
