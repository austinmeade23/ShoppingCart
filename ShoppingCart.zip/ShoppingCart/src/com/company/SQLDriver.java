package com.company;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLDriver {
    private static Connection connection;
    public static Connection initializeConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ShoppingCart","root","Rahul271*");
            if(connection!=null)
            {
                System.out.println("DB Connected...");
            }
            Statement st = connection.createStatement();
            String createProductTable="create table product(pid int(5),pname text(20),price float(5), stock int(5));";
            String createCartTable="create table cart(cid int(5), pid int(5));";
            st.execute(createProductTable);
            System.out.println("Table Products has created..");
            st.execute(createCartTable);
            System.out.println("Table Cart has created..");

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return connection;
    }

    public static Connection getConnection() {
        return connection;
    }
}
