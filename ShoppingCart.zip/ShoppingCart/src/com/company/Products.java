package com.company;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class Products {
    private final List<Product> products = new ArrayList<Product>();

    public Products () {

    }

    public List<Product> getProducts() throws SQLException {
        Connection conn = new SQLDriver().getConnection();
        Statement st = conn.createStatement();
        ResultSet allProducts = st.executeQuery("SELECT * FROM product");
        products.removeAll(products);

        while(allProducts.next()) {
            this.products.add(new Product(allProducts.getInt("pid"), allProducts.getString("pname"), allProducts.getFloat("price"), allProducts.getInt("stock")));
        }

        return products;
    }

    public void initStoreItems() throws SQLException {
        String [] productNames = {"Lux Soap", "Fair n Lovely", "MTR"};
        Float [] productPrice = {40.00f, 60.00f, 30.00f};
        Integer [] stock = {10, 6, 10};

        Connection conn = new SQLDriver().getConnection();
        PreparedStatement ps = conn.prepareStatement("insert into product values(?,?,?,?)");

        for (int i=0; i < productNames.length; i++) {
            this.products.add(new Product(i+1, productNames[i], productPrice[i], stock[i]));
            ps.setInt(1, (i+1));
            ps.setString(2, productNames[i]);
            ps.setFloat(3, productPrice[i]);
            ps.setInt(4, stock[i]);
            int count = ps.executeUpdate();
            if(count > 0) {
                System.out.println("product count = " + (i+1));
            }
        }
    }
}
